function covid() {
    var date = new Date();
    var tahun = date.getFullYear();
    var bulan = date.getMonth();
    var tanggal = date.getDate();
    switch (bulan) {
        case 0: bulan = "Januari"; break;
        case 1: bulan = "Februari"; break;
        case 2: bulan = "Maret"; break;
        case 3: bulan = "April"; break;
        case 4: bulan = "Mei"; break;
        case 5: bulan = "Juni"; break;
        case 6: bulan = "Juli"; break;
        case 7: bulan = "Agustus"; break;
        case 8: bulan = "September"; break;
        case 9: bulan = "Oktober"; break;
        case 10: bulan = "November"; break;
        case 11: bulan = "Desember"; break;
    }
    var infoTanggal = tanggal + "/" + bulan + "/" + tahun;
    document.getElementById("infoTanggall").innerHTML = (infoTanggal);

    let url = 'https://coronavirus-19-api.herokuapp.com/countries/Indonesia';
    fetch(url)
        .then(res => res.json())
        .then((out) => {
            document.getElementById("corona-positif").innerHTML = out.cases + ' Orang';
            document.getElementById("corona-positiftoday").innerHTML = out.todayCases + ' Orang';
            document.getElementById("corona-positifaktif").innerHTML = out.active + ' Orang';
            document.getElementById("corona-meninggal").innerHTML = out.deaths + ' Orang';
            document.getElementById("corona-meninggaltoday").innerHTML = out.todayDeaths + ' Orang';
            document.getElementById("corona-sembuh").innerHTML = + out.recovered + ' Orang';
        })
        .catch(err => { throw err });
}
